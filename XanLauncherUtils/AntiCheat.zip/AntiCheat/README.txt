##SETUP##
Use the XACTool to generate your launch key and game path, and move the 'xac' file into the 'XanAntiCheat' folder.


##PREPERATION##
Copy the addons directory to your project's 'res://' directory, and copy 'XanLauncher.exe' and the 'XanAntiCheat' folder to your shipped game. DO NOT Copy the 'XACTool.exe' to your game's shipping directory!

##CODE##
To check if your game has been launched from XAC, use 'XAC.new().check(<YOUR_ENCRYPTION_KEY>)'.

##HELP##
Report any issues in the XanEngine Github.